<?php
require_once "../config/db.php";

session_start();
header('Content-Type: application/json');

define('SESSION_TIMEOUT', 3600);

// Limpeza por inatividade
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > SESSION_TIMEOUT)) {
    session_unset();
    session_destroy();
    echo json_encode(["status" => "erro", "mensagem" => "Sessão expirada. Faça login novamente."]);
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time(); // Atualiza o tempo da última atividade

// Obtendo o JSON enviado
$json = json_decode(file_get_contents("php://input"), true);

if (!isset($json['nome_user368']) || !isset($json['senha_user368'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Campos obrigatórios ausentes"]);
    exit;
}

$nome = $json['nome_user368'];
$senha = $json['senha_user368'];

$sql = "SELECT senha_user368 FROM users368 WHERE nome_user368 = :nome";
$stmt = $conn->prepare($sql);
$stmt->bindParam(":nome", $nome, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result && password_verify($senha, $result["senha_user368"])) {
    $_SESSION['nome_user368'] = $nome;
    $_SESSION['LAST_ACTIVITY'] = time();

    echo json_encode([
        "status" => "success",
        "mensagem" => "Login realizado com sucesso",
        "usuario" => $nome
    ]);
} else {
    echo json_encode(["status" => "erro", "mensagem" => "Usuário ou senha incorretos"]);
}
?>
